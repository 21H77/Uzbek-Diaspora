// Founders carousel
const nextIcon = '<img src="./images/arrow-right.png" alt="right">';
const prevIcon = '<img src="./images/arrow-left.png" alt="left" >';

$(".owl-carousel").owlCarousel({
  loop: true,
  autoplay: true,
  margin: 10,
  nav: true,
  navText: [prevIcon, nextIcon],
});