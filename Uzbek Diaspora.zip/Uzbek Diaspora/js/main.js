// Smooth scroll
$('.navbar a').on('click', function (e) {
  if (this.hash !== '') {
    e.preventDefault();

    const hash = this.hash;

    $('html, body')
      .animate(
       {
        scrollTop: $(hash).offset().top -100,
       },
       800
     );
  }
});

// Burger
const navSlide = () => {
	const burger = document.querySelector('.burger');
	const nav = document.querySelector('.nav-links');
	const li = document.querySelectorAll(".nav-link");
	for (let i = 0; i < li.length; i++) {
		li[i].addEventListener("click", () => {
			nav.classList.toggle("nav-active", false);
			burger.classList.toggle("toggle", false);
		});
	}
	burger.addEventListener('click', () => {
	 nav.classList.toggle('nav-active'); 
	 burger.classList.toggle('toggle');
	});
};
navSlide();

//  Bases = Tabs

const tabItems = document.querySelectorAll('.tab-item');
const tabContentItems = document.querySelectorAll('.tab-content-item');

function selectItem(e) {
	removeBorder();
	removeShow();
	this.classList.add('tab-border');
	const tabContentItem = document.querySelector(`#${this.id}-content`);
	tabContentItem.classList.add('show');
}

function removeBorder() {
	tabItems.forEach(item => {
		item.classList.remove('tab-border');
	});
}

function removeShow() {
	tabContentItems.forEach(item => {
		item.classList.remove('show');
	});
}

tabItems.forEach(item => {
	item.addEventListener('click', selectItem);
});

const carousel = document.querySelector(".owl-carousel")

// Disable carousel on mobile version
if (window.matchMedia("(max-width: 768px)").matches) {
	console.log(carousel)
	carousel.classList.toggle("owl-carousel", false)
	carousel.classList.toggle("owl-theme", false)
  document.write('<script type="text/javascript" src="./js/carousel.js"></script>');
}


